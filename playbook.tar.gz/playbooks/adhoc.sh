#!/bin/bash
ansible all -m yum_repository -a 'name=baseos description="baseos description" baseurl=http://content.example.com/rhel9.0/x86_64/dvd/BaseOS/ enabled=yes gpgcheck=yes gpgkey=http://content.example.com/rhel9.0/x86_64/dvd/RPM-GPG-KEY-redhat-release'

ansible all -m yum_repository -a 'name=appstream description="app description" baseurl=http://content.example.com/rhel9.0/x86_64/dvd/AppStream/ enabled=yes gpgcheck=yes gpgkey=http://content.example.com/rhel9.0/x86_64/dvd/RPM-GPG-KEY-redhat-release'
